<?php echo $__env->make('pages.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- banner -->
<div class="inside-banner">
  <div class="container">
    <span class="pull-right"><a href="#">Home</a> / Contact Us</span>
    <h2>Contact Us</h2>
</div>
</div>
<!-- banner -->


<div class="container">
<div class="spacer">
<div class="row contact">
  <div class="col-lg-6 col-sm-6 ">
                <input type="text" class="form-control" placeholder="Full Name">
                <input type="text" class="form-control" placeholder="Email Address">
                <input type="text" class="form-control" placeholder="Contact Number">
                <textarea rows="6" class="form-control" placeholder="Message"></textarea>
      <button type="submit" class="btn btn-success" name="Submit">Send Message</button>




    </div>
  <div class="col-lg-6 col-sm-6 ">

    
  <div class="well">
       <h4>CORPORATE HEAD OFFICE</h4>
       <p><span class="glyphicon glyphicon-map-marker"></span> Plot 1709, Olugbosi Close,
        Off Bishop Oluwole Street,
        Victoria Island,
        Lagos, Nigeria.
        </p>

        <h4>IBADAN OFFICE</h4>
       <p><span class="glyphicon glyphicon-map-marker"></span> Plot 19, Road 5,
        Ajinde Estate,
        Oluyole Extension,
        Ibadan,
        Oyo State, Nigeria.
        </p>

        <h4>PHONE NUMBER</h4>
       <p><span class="glyphicon glyphicon-phone"></span>08023265590, 08035325701, 08033051320, 08076407690</p>

        <h4>EMAIL</h4>
       <p><span class="glyphicon glyphicon-envelope"></span> Sunnywillfamilusi@gmail.com</p>

    </div>
  </div>
</div>
</div>
</div>

<?php echo $__env->make('pages.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\sunnywillfamilusi\resources\views/pages/contact-us.blade.php ENDPATH**/ ?>