<?php echo $__env->make('pages.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="">


            <div id="slider" class="sl-slider-wrapper">

        <div class="sl-slider">
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-25" data-slice2-rotation="-25" data-slice1-scale="2" data-slice2-scale="2">
                <div class="sl-slide-inner">
                  <div class="bg-img bg-img-1" style="background-image: url('cover/<?php echo e($property->cover_image); ?>');"></div>
                  <h2><a href="#"><?php echo e($property->name); ?></a></h2>
                  <blockquote>
                  <p class="location"><span class="glyphicon glyphicon-map-marker"></span> <?php echo e($property->address); ?></p>
                  <p><?php echo e($property->description); ?></p>
                  <cite><?php echo e($property->purpose); ?> | <?php echo e($property->price); ?></cite>
                  </blockquote>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><!-- /sl-slider -->
        <nav id="nav-dots" class="nav-dots">
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="<?php echo e($loop->first ? 'nav-dot-current' : ''); ?>"></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </nav>
      </div><!-- /slider-wrapper -->
</div>

<!-- banner -->
<div class="container">
  <div class="properties-listing spacer"> <a href="/all-properties" class="pull-right viewall">View All Listing</a>
    <h2>Featured Properties</h2>
    <div id="owl-example" class="owl-carousel">
        <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="properties">
            <div class="image-holder"><img src="cover/<?php echo e($property->cover_image); ?>" class="img-responsive" alt="properties"/></div>
            <h4><a href="property-detail/<?php echo e($property->id); ?>"><?php echo e($property->name); ?></a></h4>
            <p class="price">Price: <?php echo e($property->price); ?></p>
            <div class="listing-detail"><span data-toggle="tooltip" data-placement="bottom" data-original-title="Bed Room"><?php echo e($property->bedroom); ?></span>
                 <span data-toggle="tooltip" data-placement="bottom" data-original-title="bath Room"><?php echo e($property->bathroom); ?></span>
                 <span data-toggle="tooltip" data-placement="bottom" data-original-title="Parking">2</span>
                 <span data-toggle="tooltip" data-placement="bottom" data-original-title="Kitchen">1</span> </div>
            <a class="btn btn-primary" href="property-detail/<?php echo e($property->id); ?>">View Details</a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <div class="spacer">
    <div class="row">
      <div class="col-lg-6 col-sm-9 recent-view">
        <h3>About Us</h3>
        <p>We are full-serviced real estate company, providing property valuation, Project appraisal, Property Development,
            Rental property supervision and management, from rent collection, tenant relations, evictions and mortgage and
            bill payments to disaster protection and property maintenance etc.
            <br><a href="/about-us">Learn More</a></p>
      </div>
      <div class="col-lg-5 col-lg-offset-1 col-sm-3 recommended">
        <h3>Recommended Properties</h3>
        <div id="myCarousel" class="carousel slide">
          <ol class="carousel-indicators">
              <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li data-target="#myCarousel" data-slide-to="<?php echo e($loop->first ? 'nav-dot-current' : ''); ?>" class="active"></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ol>

          <!-- Carousel items -->
          <div class="carousel-inner">
              <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item <?php echo e($loop->first ? 'active' : ''); ?>">
                <div class="row">
                  <div class="col-lg-4"><img src="cover/<?php echo e($property->cover_image); ?>" class="img-responsive" alt="properties"/></div>
                  <div class="col-lg-8">
                    <h5><a href="property-detail/<?php echo e($property->id); ?>"><?php echo e($property->name); ?></h5>
                    <p class="price"><?php echo e($property->price); ?></p>
                    <a href="/property/<?php echo e($property->id); ?>" class="more">More Detail</a>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php echo $__env->make('pages.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\sunnywillfamilusi\resources\views/pages/index.blade.php ENDPATH**/ ?>