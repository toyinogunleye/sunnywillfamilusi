<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-top: 50px">
        <div class="row">

            <div class="col-lg-3">
                <p>Cover Image:</p>
                <form action="/property/deletecoverimage/<?php echo e($properties->id); ?>" method="post">
                <button class="btn text-danger">X</button>
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                </form>
                <img src="/cover/<?php echo e($properties->cover_image); ?>" class="img-responsive" style="max-height: 100px; max-width:100px"  alt="">
                <tr>

                <?php if(count($properties->images)>0): ?>
                    <p>Images:</p>
                    <?php $__currentLoopData = $properties->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="/property/deleteimage/<?php echo e($img->id); ?>" method="post">
                        <button class="btn text-danger">X</button>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        </form>
                    <img src="/images/<?php echo e($img->image); ?>" class="img-responsive" style="max-height: 100px; max-width: 100px"  alt="">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>


                <div class="col-lg-6">
                    <h1 class="text-center text-danger">Update Property</h1>
                    <div class="form group">
                        <form action="/property/update/<?php echo e($properties->id); ?>" method="POST" enctype="multipart/form-data" class="row g-3">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("put"); ?>
                            <div class="col-12">
                                <label for="inputName" class="form-label">Property Name</label>
                                <input type="text" name="name" class="form-control" id="inputAddress" placeholder="name" value="<?php echo e($properties->name); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="inputType" class="form-label">Type</label>
                                <select id="inputState" name="type" class="form-select">
                                  <option selected><?php echo e($properties->type); ?></option>
                                  <option value="building">Building</option>
                                  <option value="apartment">Apartment</option>
                                  <option value="warehouse">Warehouse</option>
                                  <option value="land">Land</option>
                                </select>
                              </div>
                              <div class="col-md-6">
                                <label for="inputState" class="form-label">Purpose</label>
                                <select id="inputState" name="purpose" class="form-select">
                                    <option selected><?php echo e($properties->purpose); ?></option>
                                    <option value="sale">Sale</option>
                                    <option value="rent">Rent</option>
                                    <option value="lease">Lease</option>
                                </select>
                              </div>
                              <div class="col-12">
                                <label for="inputName" class="form-label">Price</label>
                                <input type="text" name="price" class="form-control" id="inputAddress" placeholder="price" value="<?php echo e($properties->price); ?>">
                            </div>
                            <div class="col-md-4">
                              <label for="inputBedroom" class="form-label">Bedroom</label>
                              <input type="text" name="bedroom" class="form-control" id="inputEmail4" value="<?php echo e($properties->bedroom); ?>">
                            </div>
                            <div class="col-md-4">
                              <label for="inputBathroom" class="form-label">Bathroom</label>
                              <input type="text" name="bathroom" class="form-control" id="inputPassword4" value="<?php echo e($properties->bathroom); ?>">
                            </div>
                            <div class="col-md-4">
                                <label for="inputArea" class="form-label">Area</label>
                                <input type="text" name="area" class="form-control" id="inputPassword4" value="<?php echo e($properties->area); ?>">
                              </div>

                            <div class="col-md-6">
                              <label for="inputCity" class="form-label">City</label>
                              <input type="text" name="city" class="form-control" id="inputCity" value="<?php echo e($properties->city); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="inputState" class="form-label">State</label>
                                <input type="text" name="state" class="form-control" id="inputCity" value="<?php echo e($properties->state); ?>">
                              </div>
                              <div class="col-12">
                                <label for="inputAddress2" class="form-label">Address</label>
                                <input type="text" name="address" class="form-control" id="inputAddress2" placeholder="Enter address" value="<?php echo e($properties->address); ?>">
                              </div>

                              <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">Description</label>
                                <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="3"><?php echo e($properties->description); ?></textarea>
                              </div>

                              <div class="mb-3">
                                <label for="formFile" class="form-label">Cover Image</label>
                                <input class="form-control" name="cover_image" type="file" id="formFile">
                              </div>
                              <div class="mb-3">
                                <label for="formFileMultiple" class="form-label">Property Images</label>
                                <input class="form-control" name="images[]" type="file" id="formFileMultiple" multiple>
                              </div>

                            
                            
                            <div class="d-grid gap-2">
                                <button class="btn btn-primary" type="submit">Submit</button>
                              </div>

                            </div>
                          </form>
                    </div>


                </div>



        </div>

    </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sunnywillfamilusi\resources\views/property/edit-property.blade.php ENDPATH**/ ?>